/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hospitalmanagementsystem;

import java.util.Random;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author walxa
 */
public class AddUser extends javax.swing.JFrame {
Admin admin;
    /**
     * Creates new form AddUser
     */
    public AddUser() {
        initComponents();
    }
    // checks if password is powerful
    public static boolean isPasswordPowerful(String password) {
        // Define the rules for a powerful password
        int minLength = 8;
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        // Check the password against the rules
        if (password.length() >= minLength) {
            for (int i = 0; i < password.length(); i++) {
                char c = password.charAt(i);
                if (Character.isUpperCase(c)) {
                    hasUpperCase = true;
                } else if (Character.isLowerCase(c)) {
                    hasLowerCase = true;
                } else if (Character.isDigit(c)) {
                    hasDigit = true;
                } else if (!Character.isLetterOrDigit(c)) {
                    hasSpecialChar = true;
                }
            }
        }

        // Return true if the password is powerful, false otherwise
        return (password.length() >= minLength) && hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
    }
    //generates id
    public static int generateid() {
        Random random = new Random();
        return 10000000 + random.nextInt(90000000);
    }
    // insert user into the user table
private void insertUser(String firstName, String lastName, int id, int age, String gender, String phoneNumber, String password, String userType) {
    try {
        DBConnection c1 = new DBConnection();
        PreparedStatement ps = c1.conn.prepareStatement("INSERT INTO user (FIRST_NAME, LAST_NAME, USER_ID, AGE, GENDER, PHONE_NUMBER, PASSWORD, TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setInt(3, id);
        ps.setInt(4, age);
        ps.setString(5, gender);
        ps.setString(6, phoneNumber);
        ps.setString(7, password);
        ps.setString(8, userType);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
//insert admin into the user table
private void insertAdmin(String firstName, String lastName, int id, int age, String gender, String phoneNumber, String password, String userType) {
    try {
        DBConnection c1 = new DBConnection();
        PreparedStatement ps = c1.conn.prepareStatement("INSERT INTO admin (FIRST_NAME, LAST_NAME, ADMIN_ID, AGE, GENDER, PHONE_NUMBER, PASSWORD, TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setInt(3, id);
        ps.setInt(4, age);
        ps.setString(5, gender);
        ps.setString(6, phoneNumber);
        ps.setString(7, password);
        ps.setString(8, userType);
        ps.executeUpdate();
        insertUser(firstName, lastName, id, age, gender, phoneNumber, password, userType);

        JOptionPane.showMessageDialog(null, "Admin Added!\ntheir ID is: " + id);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void insertDoctor(String firstName, String lastName, int id, int age, String gender, String phoneNumber, String password, String userType) {
    try {
        DBConnection c1 = new DBConnection();
        PreparedStatement ps = c1.conn.prepareStatement("INSERT INTO doctor (FIRST_NAME, LAST_NAME, DOCTOR_ID, AGE, GENDER, PHONE_NUMBER, PASSWORD, TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setInt(3, id);
        ps.setInt(4, age);
        ps.setString(5, gender);
        ps.setString(6, phoneNumber);
        ps.setString(7, password);
        ps.setString(8, userType);
        ps.executeUpdate();
        insertUser(firstName, lastName, id, age, gender, phoneNumber, password, userType);

        JOptionPane.showMessageDialog(null, "Doctor Added!\ntheir ID is: " + id);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void insertPatient(String firstName, String lastName, int id, int age, String gender, String phoneNumber, String password, String userType) {
    try {
        DBConnection c1 = new DBConnection();
        PreparedStatement ps = c1.conn.prepareStatement("INSERT INTO patient (FIRST_NAME, LAST_NAME, PATIENT_ID, AGE, GENDER, PHONE_NUMBER, PASSWORD, TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setInt(3, id);
        ps.setInt(4, age);
        ps.setString(5, gender);
        ps.setString(6, phoneNumber);
        ps.setString(7, password);
        ps.setString(8, userType);
        ps.executeUpdate();
        insertUser(firstName, lastName, id, age, gender, phoneNumber, password, userType);

        JOptionPane.showMessageDialog(null, "Patient Added!\ntheir ID is: " + id);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void insertReceptionist(String firstName, String lastName, int id, int age, String gender, String phoneNumber, String password, String userType) {
    try {
        DBConnection c1 = new DBConnection();
        PreparedStatement ps = c1.conn.prepareStatement("INSERT INTO receptionist (FIRST_NAME, LAST_NAME, RECEPTIONIST_ID, AGE, GENDER, PHONE_NUMBER, PASSWORD, TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        ps.setString(1, firstName);
        ps.setString(2, lastName);
        ps.setInt(3, id);
        ps.setInt(4, age);
        ps.setString(5, gender);
        ps.setString(6, phoneNumber);
        ps.setString(7, password);
        ps.setString(8, userType);
        ps.executeUpdate();
        insertUser(firstName, lastName, id, age, gender, phoneNumber, password, userType);

        JOptionPane.showMessageDialog(null, "Receptionist Added!\ntheir ID is: " + id);
    } catch (Exception e) {
        e.printStackTrace();
    }
}
private void resetFields() {
    firstname.setText("");
    lastname.setText("");
    agetxt.setText("");
    phonenumber.setText("");
    passtxt.setText("");

    typebox.setSelectedIndex(0);
    genderbox.setSelectedIndex(0);
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        typebox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        firstname = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lastname = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        agetxt = new javax.swing.JTextField();
        genderbox = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        phonenumber = new javax.swing.JTextField();
        addbutton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        passtxt = new javax.swing.JPasswordField();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1093, 678));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/signup.png"))); // NOI18N

        typebox.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        typebox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADMIN", "PATIENT", "DOCTOR", "RECEPTIONIST" }));
        typebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeboxActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel1.setText("User Type:");

        firstname.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel2.setText("First Name:");

        jLabel4.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel4.setText("Last Name:");

        lastname.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel5.setText("Age:");

        agetxt.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        genderbox.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        genderbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        genderbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genderboxActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel6.setText("Gender:");

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel7.setText("Password:");

        jLabel9.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel9.setText("Phone Number:");

        phonenumber.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        phonenumber.setToolTipText("10 digits and start with '05'");

        addbutton.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        addbutton.setText("ADD");
        addbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbuttonActionPerformed(evt);
            }
        });

        backButton.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        passtxt.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        passtxt.setToolTipText("A powerful password should be at least 8 characters long\ncontain at least one uppercase letter, one lowercase letter\none digit and one special character");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(221, 221, 221)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(addbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(433, 433, 433))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(firstname)
                            .addComponent(typebox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lastname)
                            .addComponent(agetxt)
                            .addComponent(genderbox, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(phonenumber)
                            .addComponent(passtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addGap(131, 131, 131))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(typebox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(firstname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lastname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(agetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(genderbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phonenumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(passtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addbutton)
                    .addComponent(backButton))
                .addGap(90, 90, 90))
        );

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1088, 113));

        jLabel3.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel3.setText("ADD USER");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(418, 418, 418)
                .addComponent(jLabel3)
                .addContainerGap(463, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel3)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1093, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 110, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 580, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void typeboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeboxActionPerformed

    private void genderboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genderboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_genderboxActionPerformed

    private void addbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbuttonActionPerformed
        // Phone number validator 
    final String PHONE_REGEX = "^05[0-9]{8}$";
    final Pattern PHONE_PATTERN = Pattern.compile(PHONE_REGEX);
    boolean phoneValid = false;
    if (evt.getSource() == addbutton) {
        String firstName = firstname.getText();
        String lastName = lastname.getText();
//        int age = Integer.parseInt(agetxt.getText());
        String agemp = agetxt.getText();
        String gender = genderbox.getSelectedItem().toString();
        String phoneNumber = phonenumber.getText();
        char[] password = passtxt.getPassword();
        int id = generateid();
        String userType = typebox.getSelectedItem().toString(); // Get the selected user type

        // Validate fields
        boolean emptyValid = !firstName.isEmpty() && !lastName.isEmpty() && !phoneNumber.isEmpty() && !agemp.isEmpty();
        Matcher matcher = PHONE_PATTERN.matcher(phoneNumber); 
        phoneValid = matcher.matches();
        boolean passwordIsPowerful = isPasswordPowerful(new String(password));

        if (!emptyValid) {
            JOptionPane.showMessageDialog(null, "Some fields are empty");
        } else if (!phoneValid) {
            JOptionPane.showMessageDialog(null, "Phone number is not valid\n it should only contain 10 numbers and start with 05 ");
        } else if (!passwordIsPowerful) {
            JOptionPane.showMessageDialog(null, "Your password is not powerful!\n"
                    + "A powerful password should be at least 8 characters long\n"
                    + "contain at least one uppercase letter, one lowercase letter\n"
                    + "one digit and one special character.");
        } else if (!firstName.matches("^[a-zA-Z]*$") || !lastName.matches("^[a-zA-Z]*$")) {
            JOptionPane.showMessageDialog(null, "First Name and Last Name are not valid, they should contain only letters");
        } else if (!agemp.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Age must only be a number");
        }
            else {
                int age = Integer.parseInt(agetxt.getText());
                if (age < 0 || age >= 150) {
                    
                    JOptionPane.showMessageDialog(null, "Age must be a non-negative number less than 150");
                }
        else {
           // int age = Integer.parseInt(agetxt.getText());
            // Perform insertion based on user type
            switch (userType) {
                case "ADMIN":
                    insertAdmin(firstName, lastName, id, age, gender, phoneNumber, new String(password), userType);
                    resetFields();
                    break;
                case "PATIENT":
                    insertPatient(firstName, lastName, id, age, gender, phoneNumber, new String(password), userType);
                    resetFields();
                    break;
                case "DOCTOR":
                    insertDoctor(firstName, lastName, id, age, gender, phoneNumber, new String(password), userType);
                    resetFields();
                    break;
                case "RECEPTIONIST":
                    insertReceptionist(firstName, lastName, id, age, gender, phoneNumber, new String(password), userType);
                    resetFields();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid user type");
                    break;
            }
        }
    }
    }

    }//GEN-LAST:event_addbuttonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        AdminView a = new AdminView(admin);
        a.setVisible(true);
        dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbutton;
    private javax.swing.JTextField agetxt;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField firstname;
    private javax.swing.JComboBox<String> genderbox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField lastname;
    private javax.swing.JPasswordField passtxt;
    private javax.swing.JTextField phonenumber;
    private javax.swing.JComboBox<String> typebox;
    // End of variables declaration//GEN-END:variables
}
