/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hospitalmanagementsystem;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Dhaim
 */
public class DeleteUserView extends javax.swing.JFrame {
Admin admin;
Connection conn;
    PreparedStatement pstmt;
    ResultSet rs;
    /**
     * Creates new form DeleteUserView
     */
    public DeleteUserView() {
        initComponents();
    try {
        conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db","root","root");
    } catch (SQLException ex) {
        Logger.getLogger(DeleteUserView.class.getName()).log(Level.SEVERE, null, ex);
    }
    populateTable("ADMIN");
    }
    private void populateTable(String userType) {
        try {
            String sql = "SELECT FIRST_NAME, LAST_NAME, USER_ID FROM user WHERE TYPE = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userType);
            rs = pstmt.executeQuery();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                String firstName = rs.getString("FIRST_NAME");
                String lastName = rs.getString("LAST_NAME");
                int id = rs.getInt("USER_ID");
                model.addRow(new Object[]{firstName, lastName, id});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }
private void deleteAdmin(int id) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        PreparedStatement ps = conn.prepareStatement("DELETE FROM admin WHERE ADMIN_ID = ?");
        ps.setInt(1, id);

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            PreparedStatement psUser = conn.prepareStatement("DELETE FROM user WHERE USER_ID = ?");
            psUser.setInt(1, id);
            psUser.executeUpdate();
            JOptionPane.showMessageDialog(null, "Admin with ID: " + id + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Admin with ID: " + id + " does not exist.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting admin: " + e.getMessage());
        e.printStackTrace();
    }
}
private void deletePatient(int id) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        deleteAppointmentsForPatient(id);
        PreparedStatement ps = conn.prepareStatement("DELETE FROM patient WHERE PATIENT_ID = ?");
        ps.setInt(1, id);

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            PreparedStatement psUser = conn.prepareStatement("DELETE FROM user WHERE USER_ID = ?");
            psUser.setInt(1, id);
            psUser.executeUpdate();
            JOptionPane.showMessageDialog(null, "Patient with ID: " + id + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Patient with ID: " + id + " does not exist.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting patient: " + e.getMessage());
        e.printStackTrace();
    }
}
private void deleteDoctor(int id) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        deleteAppointmentsForDoctor(id);
        PreparedStatement ps = conn.prepareStatement("DELETE FROM doctor WHERE DOCTOR_ID = ?");
        ps.setInt(1, id);

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            PreparedStatement psUser = conn.prepareStatement("DELETE FROM user WHERE USER_ID = ?");
            psUser.setInt(1, id);
            psUser.executeUpdate();
            JOptionPane.showMessageDialog(null, "Doctor with ID: " + id + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Doctor with ID: " + id + " does not exist.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting doctor: " + e.getMessage());
        e.printStackTrace();
    }
}
private void deleteReceptionist(int id) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        PreparedStatement ps = conn.prepareStatement("DELETE FROM receptionist WHERE RECEPTIONIST_ID = ?");
        ps.setInt(1, id);

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            PreparedStatement psUser = conn.prepareStatement("DELETE FROM user WHERE USER_ID = ?");
            psUser.setInt(1, id);
            psUser.executeUpdate();
            JOptionPane.showMessageDialog(null, "Admin with ID: " + id + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Admin with ID: " + id + " does not exist.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting admin: " + e.getMessage());
        e.printStackTrace();
    }
}
//delete appointments that have the doctor id
private void deleteAppointmentsForDoctor(int doctorId) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        String sql = "DELETE FROM appointment WHERE DOCTOR_ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, doctorId);
        ps.executeUpdate();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting associated appointments: " + e.getMessage());
        e.printStackTrace();
    }
}
//delete appointments that have the patient id
private void deleteAppointmentsForPatient(int patientId) {
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        String sql = "DELETE FROM appointment WHERE PATIENT_ID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, patientId);
        
        
        ps.executeUpdate();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error deleting associated appointments: " + e.getMessage());
        e.printStackTrace();
    }
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        typebox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        deletebutton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Delete User");
        setPreferredSize(new java.awt.Dimension(1093, 678));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1093, 678));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/delete_user (1).png"))); // NOI18N

        jButton2.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "First Name", "Last Name", "ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable1);

        typebox.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        typebox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADMIN", "PATIENT", "DOCTOR", "RECEPTIONIST" }));
        typebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeboxActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel1.setText("User Type:");

        deletebutton.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        deletebutton.setText("Delete");
        deletebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(289, 289, 289)
                .addComponent(deletebutton, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(579, 579, 579))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(typebox, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(51, 51, 51))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(typebox, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(deletebutton)
                    .addComponent(jButton2))
                .addContainerGap(121, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 51, 51));
        jPanel2.setPreferredSize(new java.awt.Dimension(1088, 113));

        jLabel3.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel3.setText("Delete User");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(400, 400, 400)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel3)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1100, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1100, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 588, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        AdminView a = new AdminView(admin);
        a.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void deletebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebuttonActionPerformed
        // TODO add your handling code here:
        int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to delete.");
        return;
    }
    String userType = (String) typebox.getSelectedItem();
    int id = (int) jTable1.getValueAt(selectedRow, 2); 
    switch (userType) {
        case "ADMIN":
            deleteAdmin(id);
            break;
        case "PATIENT":
            deletePatient(id);
            break;
        case "DOCTOR":
            deleteDoctor(id);
            break;
        case "RECEPTIONIST":
            deleteReceptionist(id);
            break;
        default:
            JOptionPane.showMessageDialog(null, "Invalid user type.");
            break;
    }
    populateTable(userType);
    }//GEN-LAST:event_deletebuttonActionPerformed

    private void typeboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeboxActionPerformed
        // TODO add your handling code here:
        String userType = (String) typebox.getSelectedItem();
                populateTable(userType);
    }//GEN-LAST:event_typeboxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeleteUserView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeleteUserView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeleteUserView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeleteUserView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeleteUserView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton deletebutton;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> typebox;
    // End of variables declaration//GEN-END:variables
}
