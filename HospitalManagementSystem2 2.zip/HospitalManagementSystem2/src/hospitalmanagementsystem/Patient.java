package hospitalmanagementsystem;

public class Patient extends User {

    public Patient(String firstName, String lastName, int ID, int age, String gender, String phoneNumber, String password, String type) {
        super(firstName, lastName, ID, age, gender, phoneNumber, password, type);
    }
    

}