package hospitalmanagementsystem;

public class Receptionist extends User {

    public Receptionist(String firstName, String lastName, int ID, int age, String gender, String phoneNumber, String password, String type) {
        super(firstName, lastName, ID, age, gender, phoneNumber, password, type);
    }
    

}