/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hospitalmanagementsystem;

import java.util.Random;
import java.sql.*;
import java.util.Calendar;
import javax.swing.JOptionPane;
/**
 *
 * @author Donya
 */
public class ScheduleAppointment extends javax.swing.JFrame {
Receptionist receptionist;
    /**
     * Creates new form ScheduleAppointment
     */
    public ScheduleAppointment() {
        initComponents();
        getPatient();
        getDoctor();
        getRoom();
        jDateChooser1.setDate(Calendar.getInstance().getTime());
    }
    Connection con= null;
    Statement st=null, st1= null, st2= null, pst= null;
    ResultSet rs=null, rs1=null, rs2= null, rs3= null;
    private static final Random RANDOM = new Random();
    private static final String LETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGITS = "0123456789";
//to generate procedure code
    public static String generateCode() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            int index = RANDOM.nextInt(LETTERS.length());
            sb.append(LETTERS.charAt(index));
        }
        sb.append("-");
        for (int i = 0; i < 2; i++) {
            int index = RANDOM.nextInt(DIGITS.length());
            sb.append(DIGITS.charAt(index));
        }

        return sb.toString();
    }
    //get patients ids
    private void getPatient(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db","root","root");
            st = con.createStatement();
            String query = "Select * from patient";
            rs = st.executeQuery(query);
            while(rs.next()){
                String myPat = rs.getString("PATIENT_ID");
                patientselect.addItem(myPat);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    //get doctors ids
    private void getDoctor(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db","root","root");
            st1 = con.createStatement();
            String query = "Select * from doctor";
            rs1 = st1.executeQuery(query);
            while(rs1.next()){
                String myDoc = rs1.getString("DOCTOR_ID");
                doctorselect.addItem(myDoc);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    //get unoccupied rooms
    private void getRoom(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db","root","root");
            st2 = con.createStatement();
            String query = "SELECT ROOM_NUMBER FROM room WHERE ROOM_OCCUPIED = 'NO'";
            rs2 = st2.executeQuery(query);
            while(rs2.next()){
                int room = rs2.getInt("ROOM_NUMBER");
                roomselect.addItem(String.valueOf(room));
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    //Check if the doctor available
    private boolean isAppointmentConflict(int doctorId, Date appointmentDate, String appointmentTime) {
    boolean conflict = false;
    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        PreparedStatement pst = con.prepareStatement("SELECT * FROM appointment WHERE DOCTOR_ID = ? AND DATE = ? AND TIME = ?");
        pst.setInt(1, doctorId);
        pst.setDate(2, appointmentDate);
        pst.setString(3, appointmentTime);
        ResultSet rs3 = pst.executeQuery();
        conflict = rs3.next();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return conflict;
}
    //Check if the patient has appointment
    private boolean isAppointmentConflict2(int patientId, Date appointmentDate, String appointmentTime) {
    boolean conflict = false;
    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        PreparedStatement pst = con.prepareStatement("SELECT * FROM appointment WHERE PATIENT_ID = ? AND DATE = ? AND TIME = ?");
        pst.setInt(1, patientId);
        pst.setDate(2, appointmentDate);
        pst.setString(3, appointmentTime);
        ResultSet rs3 = pst.executeQuery();
        conflict = rs3.next();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return conflict;
}
    //Check if room available
    private boolean isRoomOccupied(int roomNumber, Date appointmentDate, String appointmentTime) {
    boolean occupied = false;
    try {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "root");
        PreparedStatement pst = con.prepareStatement("SELECT * FROM appointment WHERE ROOM_NUMBER = ? AND DATE = ? AND TIME = ?");
        pst.setInt(1, roomNumber);
        pst.setDate(2, appointmentDate);
        pst.setString(3, appointmentTime);
        ResultSet rs = pst.executeQuery();
        occupied = rs.next();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return occupied;
}

// clear fields after scheduling an appointment    
    private void clearFields() {
    patientselect.setSelectedIndex(0);
    doctorselect.setSelectedIndex(0);
    roomselect.removeAllItems();
    getRoom();
    jDateChooser1.setDate(Calendar.getInstance().getTime());
    proc.setText("");
    duration.setText("");
    timeselect.setSelectedIndex(0);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        backButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        patientselect = new javax.swing.JComboBox<>();
        doctorselect = new javax.swing.JComboBox<>();
        roomselect = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        proc = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        duration = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        timeselect = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Schedule Appointment");
        setBackground(new java.awt.Color(206, 230, 255));
        setPreferredSize(new java.awt.Dimension(1093, 678));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        backButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel3.setText("Schedule Appointment");

        jButton2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jButton2.setText("Schedule ");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        patientselect.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        doctorselect.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        roomselect.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel1.setText("Patient:");

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel2.setText("Doctor:");

        jLabel4.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel4.setText("Room:");

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel5.setText("Date:");

        proc.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        proc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                procActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel6.setText("Procedure Name:");

        duration.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel7.setText("Duration:");

        timeselect.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        timeselect.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "09:00", "10:00", "11:00", "12:00", "01:00", "02:00", "03:00", "04:00" }));

        jLabel8.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel8.setText("Time:");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pics/appoint (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(proc, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton2))
                                .addGap(18, 18, 18)
                                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(patientselect, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(99, 99, 99))
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(doctorselect, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(timeselect, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(103, 103, 103)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(roomselect, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(duration, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(103, 103, 103)
                        .addComponent(jLabel9)))
                .addContainerGap(241, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jLabel3)
                .addGap(86, 86, 86)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(patientselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(doctorselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(4, 4, 4)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(duration, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(timeselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(27, 27, 27)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(proc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(23, 23, 23)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(backButton))
                .addGap(110, 110, 110))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void procActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_procActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_procActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int id = generateid();
        String pcode = generateCode();
        // int durationint = Integer.parseInt(duration.getText());
        int patientid = Integer.parseInt(patientselect.getSelectedItem().toString());
        int doctorid = Integer.parseInt(doctorselect.getSelectedItem().toString());
        int roomno = Integer.parseInt(roomselect.getSelectedItem().toString());
        java.util.Date date = jDateChooser1.getDate();
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
        String time = timeselect.getSelectedItem().toString();
        if (duration.getText().isEmpty() || proc.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Missing Information");
        } else {
            if (isAppointmentConflict2(patientid, sqlDate, time)) {
                JOptionPane.showMessageDialog(this, "The patient has an appointment at the selected time and date");
            }
            else if (isAppointmentConflict(doctorid, sqlDate, time)) {
                JOptionPane.showMessageDialog(this, "The doctor has an appointment at the selected time and date");
            }
            else if (isRoomOccupied(roomno, sqlDate, time)) {
                JOptionPane.showMessageDialog(this, "The room is already occupied at the selected time and date");
            }
            else {
                try{
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db","root","root");
                    PreparedStatement add = con.prepareStatement("INSERT INTO appointment (APPOINTMENT_ID, DATE, TIME, PATIENT_ID, DOCTOR_ID, ROOM_NUMBER, PROCEDURE_CODE, PROCEDURE_NAME) VALUES (?, ?, ?, ?, ?, ?, ?,?)");
                    add.setInt(1, id);
                    add.setDate(2, sqlDate);
                    add.setString(3, time);
                    add.setInt(4, patientid);
                    add.setInt(5, doctorid);
                    add.setInt(6,roomno);
                    add.setString(7, pcode);
                    add.setString(8, proc.getText());
                    add.executeUpdate();
                    //               String updateQuery = "UPDATE room SET ROOM_OCCUPIED = 'YES' WHERE ROOM_NUMBER = ?";
                    //            PreparedStatement updateRoom = con.prepareStatement(updateQuery);
                    //            updateRoom.setInt(1, roomno);
                    //            updateRoom.executeUpdate();
                    PreparedStatement add2 = con.prepareStatement("INSERT INTO procedures (CODE, NAME, DURATION, SCHEDULED_DATE, SCHEDULED_TIME,PATIENT_ID) VALUES (?, ?, ?, ?, ?, ?)");
                    add2.setString(1, pcode);
                    add2.setString(2, proc.getText());
                    add2.setInt(3, Integer.parseInt(duration.getText()));
                    add2.setDate(4, sqlDate);
                    add2.setString(5, time);
                    add2.setInt(6, patientid);
                    add2.executeUpdate();
                    JOptionPane.showMessageDialog(this,"Appointment Scheduled Successfully");
                    clearFields();
                    con.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        // TODO add your handling code here:
        ReceptionistView u = new ReceptionistView(receptionist);
        u.setVisible(true);
        dispose();
    }//GEN-LAST:event_backButtonActionPerformed
//generate appointment id
    public static int generateid() {
        Random random = new Random();
        return random.nextInt(900) + 100; // Generates a random number between 100 (inclusive) and 999 (exclusive)
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScheduleAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScheduleAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScheduleAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScheduleAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScheduleAppointment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JComboBox<String> doctorselect;
    private javax.swing.JTextField duration;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> patientselect;
    private javax.swing.JTextField proc;
    private javax.swing.JComboBox<String> roomselect;
    private javax.swing.JComboBox<String> timeselect;
    // End of variables declaration//GEN-END:variables
}
