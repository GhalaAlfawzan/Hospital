/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagementsystem;

public class User {
    private String firstName;
    private String lastName;
    private int ID;
    private int age;
    private String gender;
    private String phoneNumber;
    private String password;
    private String type;
    public User(){
        
    }
    public User(String firstName, String lastName, int ID, int age, String gender, String phoneNumber, String password, String type){
    this.firstName = firstName;
    this.lastName = lastName;
    this.ID = ID;
    this.age = age;
    this.gender = gender;
    this.phoneNumber = phoneNumber;
    this.password=password;
    this.type = type;
    }
    
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    } 
    
    public int getID(){
        return ID;
    }
    public int getAge(){
        return age;
    }
    public String getGender(){
        return gender;
    }
    public String getPhoneNumber(){
        return phoneNumber;
    }
    public String getPassword() {
        return password;
    }
    public String getType(){
        return type;
    }
//*********Mutator/setters********
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setType(String type){
        this.type=type;
    }

    public void setPassword(String password) {
    this.password = password;

        }

    
}
